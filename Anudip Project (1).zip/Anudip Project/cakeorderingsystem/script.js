document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    // Add your form submission logic here
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return;
    }

    alert('Form submitted successfully!');
    // Optionally, submit the form here
    // this.submit();
});
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    // Add your form submission logic here
    alert('Form submitted successfully!');
    // Optionally, submit the form here
    // this.submit();
});

function resetForm() {
    document.getElementById('loginForm').reset();
}
